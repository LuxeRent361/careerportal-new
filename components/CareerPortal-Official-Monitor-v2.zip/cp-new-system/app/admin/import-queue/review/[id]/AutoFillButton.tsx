"use client";

import { useState } from "react";

type Props = { id: string };
type ApiResponse = {
  success?: boolean;
  fields?: Record<string, unknown>;
  message?: string;
  error?: string;
  extractedCharacters?: number;
  extractionMethod?: string;
  sourceUrl?: string;
  pdfPages?: number;
};

const aliases: Record<string, string> = {
  headline: "title",
  post_title: "title",
  name: "title",
  department_name: "organization",
  organisation: "organization",
  company_name: "organization",
  post_name: "post_name",
  position: "post_name",
  vacancies: "total_vacancies",
  total_posts: "total_vacancies",
  number_of_vacancies: "total_vacancies",
  educational_qualification: "qualification",
  education_qualification: "qualification",
  essential_qualification: "qualification",
  ageLimit: "age_limit",
  pay_scale: "salary",
  salary_details: "salary",
  fee: "application_fee",
  fees: "application_fee",
  start_date: "application_start",
  application_start_date: "application_start",
  end_date: "last_date",
  last_date_to_apply: "last_date",
  lastDate: "last_date",
  admit_card_release_date: "admit_card_date",
  release_date: "admit_card_date",
  result_url: "result_url",
  application_url: "apply_url",
  pdf_url: "notification_url",
  document_url: "notification_url",
  official_url: "official_website",
  website: "official_website",
  summary: "description",
  details: "description",
  body: "description",
  required_documents: "required_documents",
  documents_required: "required_documents",
  answerKeyUrl: "answer_key_url",
  admitCardUrl: "admit_card_url",
  notice_title: "title",
  noticeTitle: "title",
  recruiting_organization: "organization",
  number_of_vacancies: "total_vacancies",
  no_of_vacancies: "total_vacancies",
  application_fees: "application_fee",
  registration_start_date: "application_start",
  application_deadline: "last_date",
  lastdate: "last_date",
  official_pdf_url: "notification_url",
  notification_pdf: "notification_url",
  documents_required: "required_documents",
  answerkeyurl: "answer_key_url",
  admitcardurl: "admit_card_url",
  syllabus_pdf_url: "syllabus_url",
  location: "job_location",
};

function toText(value: unknown): string {
  if (typeof value === "string") return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) return value.map(toText).filter(Boolean).join("\n");
  if (value && typeof value === "object") return JSON.stringify(value, null, 2);
  return "";
}


function normalizeKey(key: string): string {
  const normalized = key.trim().replace(/([a-z0-9])([A-Z])/g, "$1_$2").replace(/[\s-]+/g, "_").toLowerCase();
  return aliases[normalized] || aliases[key] || normalized;
}

function parseDate(value: string): string {
  const s = value.trim();
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return s;
  const dmy = s.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
  if (dmy) return `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}`;
  const months: Record<string, string> = { jan:"01", january:"01", feb:"02", february:"02", mar:"03", march:"03", apr:"04", april:"04", may:"05", jun:"06", june:"06", jul:"07", july:"07", aug:"08", august:"08", sep:"09", sept:"09", september:"09", oct:"10", october:"10", nov:"11", november:"11", dec:"12", december:"12" };
  const m = s.match(/^(\d{1,2})\s+([A-Za-z]+),?\s+(\d{4})$/) || s.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})$/);
  if (m) {
    const day = /^\d/.test(m[1]) ? m[1] : m[2];
    const monthName = /^\d/.test(m[1]) ? m[2] : m[1];
    const year = m[3];
    const month = months[monthName.toLowerCase()];
    if (month) return `${year}-${month}-${day.padStart(2, "0")}`;
  }
  return "";
}

export default function AutoFillButton({ id }: Props) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState(false);

  async function runAutoFill() {
    setLoading(true);
    setMessage("");
    setError(false);

    try {
      const response = await fetch(`/api/admin/import-queue/${encodeURIComponent(id)}/autofill`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
      });
      const result = (await response.json().catch(() => ({}))) as ApiResponse;

      if (!response.ok || !result.success) {
        throw new Error(result.error || result.message || `Auto Fill failed (HTTP ${response.status}).`);
      }

      const form = document.getElementById("content-details-form") as HTMLFormElement | null;
      if (!form) throw new Error("Content Details form नहीं मिला। Page reload करके दोबारा कोशिश करें।");

      const fields = result.fields && typeof result.fields === "object" ? result.fields : {};
      const extraBox = form.elements.namedItem("extra_details_json") as HTMLTextAreaElement | null;
      let extra: Record<string, unknown> = {};
      try {
        extra = extraBox?.value.trim() ? JSON.parse(extraBox.value) : {};
        if (!extra || typeof extra !== "object" || Array.isArray(extra)) extra = {};
      } catch {
        throw new Error("Extra Source Details (JSON) में invalid JSON है। पहले उसे ठीक करें या खाली करें।");
      }

      let filled = 0;
      let preserved = 0;
      let unmatched = 0;

      for (const [originalKey, rawValue] of Object.entries(fields)) {
        const value = toText(rawValue);
        if (!value) continue;
        const key = normalizeKey(originalKey);
        const element = form.elements.namedItem(key);

        if (!element) {
          // Retain any field that has no dedicated form input, instead of dropping it.
          if (!(key in extra)) extra[key] = rawValue;
          unmatched++;
          continue;
        }

        const controls = element instanceof RadioNodeList ? Array.from(element) : [element];
        let didFill = false;
        let wasAlreadyFilled = false;

        for (const control of controls) {
          if (!(control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement || control instanceof HTMLSelectElement)) continue;
          if (control.value.trim()) {
            wasAlreadyFilled = true;
            continue;
          }

          if (control instanceof HTMLSelectElement) {
            const match = Array.from(control.options).find(option =>
              option.value.toLowerCase() === value.toLowerCase() || option.text.trim().toLowerCase() === value.toLowerCase()
            );
            if (match) {
              control.value = match.value;
              control.dispatchEvent(new Event("change", { bubbles: true }));
              didFill = true;
            }
          } else {
            if (control instanceof HTMLInputElement && control.type === "date") {
              const parsedDate = parseDate(value);
              if (!parsedDate) {
                if (!(key in extra)) extra[key] = rawValue;
                unmatched++;
                continue;
              }
              control.value = parsedDate;
            } else {
              control.value = value;
            }
            control.dispatchEvent(new Event("input", { bubbles: true }));
            control.dispatchEvent(new Event("change", { bubbles: true }));
            didFill = true;
          }
        }

        if (didFill) filled++;
        else if (wasAlreadyFilled) preserved++;
        else {
          if (!(key in extra)) extra[key] = rawValue;
          unmatched++;
        }
      }

      if (extraBox) {
        extraBox.value = JSON.stringify(extra, null, 2);
        extraBox.dispatchEvent(new Event("input", { bubbles: true }));
        extraBox.dispatchEvent(new Event("change", { bubbles: true }));
      }
      const method = result.extractionMethod ? `\nExtraction: ${result.extractionMethod}` : "";
      const pages = typeof result.pdfPages === "number" && result.pdfPages > 0 ? `\nPDF pages: ${result.pdfPages}` : "";
      const source = result.sourceUrl ? `\nSource: ${result.sourceUrl}` : "";
      setMessage(`${filled} खाली fields भरी गईं। ${preserved} पहले से भरी fields सुरक्षित रहीं। ${unmatched} जानकारी Extra Source Details (JSON) में रखी गई।${method}${pages}${source}\nअब सभी fields जाँचें और Save Content Details दबाएँ।`);
    } catch (caught) {
      setError(true);
      setMessage(caught instanceof Error ? caught.message : "Auto Fill के दौरान अज्ञात त्रुटि हुई।");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={runAutoFill}
        disabled={loading}
        className="inline-flex items-center justify-center rounded-xl bg-blue-700 px-5 py-3 text-sm font-extrabold text-white shadow-sm transition hover:bg-blue-800 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading ? "Official Notice पढ़ रहा है…" : "Auto Fill from Official Notice / PDF"}
      </button>
      {message && (
        <p role="status" className={`mt-3 rounded-lg p-3 text-sm leading-6 ${error ? "border border-red-200 bg-red-50 text-red-800" : "border border-blue-200 bg-white text-blue-950"}`}>
          {message}
        </p>
      )}
    </div>
  );
}
