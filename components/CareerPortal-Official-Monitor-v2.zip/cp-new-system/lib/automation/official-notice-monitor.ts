import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export type NoticeType = "job" | "exam" | "result" | "admit_card" | "answer_key" | "syllabus" | "education" | "notification";
type Source = { id: string; name: string; code: string; website_url: string; is_active?: boolean };
type Candidate = { title: string; url: string; type: NoticeType };
type Json = Record<string, unknown>;

const TIMEOUT_MS = 14_000;
const MAX_HTML_BYTES = 3_000_000;
const MAX_NOTICE_BYTES = 12_000_000;
const MAX_LINKS_PER_SOURCE = 45;
const MAX_SOURCES_PER_RUN = 40;

export function adminDb(): SupabaseClient {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error("NEXT_PUBLIC_SUPABASE_URL या SUPABASE_SERVICE_ROLE_KEY missing है।");
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

function decode(s: string): string {
  return s.replace(/&nbsp;|&#160;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_m, n: string) => { const v = Number(n); return v > 0 && v <= 0x10ffff ? String.fromCodePoint(v) : " "; })
    .replace(/&#x([\da-f]+);/gi, (_m, n: string) => { const v = parseInt(n, 16); return v > 0 && v <= 0x10ffff ? String.fromCodePoint(v) : " "; });
}
function cleanHtml(html: string): string {
  return decode(html.replace(/<(script|style|noscript|svg|nav|header|footer|aside)\b[^>]*>[\s\S]*?<\/\1>/gi, " ")
    .replace(/<!--([\s\S]*?)-->/g, " ").replace(/<\/(p|div|li|tr|h[1-6]|section|article|br|td|th)>/gi, "\n")
    .replace(/<[^>]+>/g, " ")).replace(/[\t\r ]+/g, " ").replace(/ *\n */g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}
function normalizeUrl(raw: string, base: string): string | null {
  try {
    const u = new URL(raw, base);
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    if (u.username || u.password) return null;
    u.hash = "";
    if (!u.pathname.toLowerCase().endsWith(".pdf")) {
      for (const key of [...u.searchParams.keys()]) if (/^(utm_|fbclid|gclid)/i.test(key)) u.searchParams.delete(key);
    }
    return u.toString();
  } catch { return null; }
}
function sameOfficialHost(url: string, sourceUrl: string): boolean {
  try {
    const host = new URL(url).hostname.toLowerCase().replace(/^www\./, "");
    const root = new URL(sourceUrl).hostname.toLowerCase().replace(/^www\./, "");
    return host === root || host.endsWith(`.${root}`);
  } catch { return false; }
}
function classify(title: string, href: string): NoticeType | null {
  const s = `${title} ${href}`.toLowerCase();
  if (/\b(result|merit list|score ?card|marks uploaded|cut.?off|selected candidates)\b/.test(s)) return "result";
  if (/\b(admit.?card|hall.?ticket|e.?call letter|download call letter)\b/.test(s)) return "admit_card";
  if (/\b(answer.?key|response sheet|objection window|provisional key|final key)\b/.test(s)) return "answer_key";
  if (/\b(syllabus|exam pattern|curriculum|scheme of examination)\b/.test(s)) return "syllabus";
  if (/\b(exam date|exam schedule|examination calendar|date sheet|postponed|rescheduled|time table)\b/.test(s)) return "exam";
  if (/\b(recruitment|vacanc(?:y|ies)|employment notice|advertisement no|advt\.? no|apply online|applications invited|engagement of|notification for the post|apprentice|direct recruitment|selection process)\b/.test(s)) return "job";
  if (/\b(admission|entrance|scholarship|fellowship|course notification|academic session|counselling|counseling)\b/.test(s)) return "education";
  if (/\b(important notice|public notice|corrigendum|addendum|extension of date|revised notification|notice regarding|official notification)\b/.test(s)) return "notification";
  return null;
}
const JUNK = /^(home|home page|about( us)?|contact( us)?|careers?|recruitment|results?|admit cards?|answer keys?|syllabus|notifications?|notices?|announcements?|latest news|latest updates|view all|read more|click here|download|login|register|privacy policy|terms|site map|sitemap|search|menu|advertisements?)$/i;
function validTitle(s: string): boolean {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length >= 9 && t.length <= 240 && !JUNK.test(t) && !/^(click|view|read|download|know)\s+(here|more|all|now)/i.test(t);
}
function linkContext(html: string, start: number, end: number): string {
  const before = html.slice(0, start);
  const after = html.slice(end);
  // Prefer the nearest notice row/list item/card; avoid treating the entire homepage as one notice.
  const tags = ["tr", "li", "article"];
  let best = "";
  for (const tag of tags) {
    const open = before.toLowerCase().lastIndexOf(`<${tag}`);
    if (open < 0) continue;
    const close = after.toLowerCase().indexOf(`</${tag}>`);
    if (close < 0) continue;
    const candidate = html.slice(open, end + close + tag.length + 3);
    if (!best || candidate.length < best.length) best = candidate;
  }
  return (best || html.slice(Math.max(0, start - 450), Math.min(html.length, end + 450))).slice(0, 7000);
}
function findCandidates(html: string, pageUrl: string, sourceUrl: string): Candidate[] {
  const out = new Map<string, Candidate>();
  const anchor = /<a\b([^>]*?)href\s*=\s*(["'])(.*?)\2([^>]*)>([\s\S]*?)<\/a>/gi;
  let m: RegExpExecArray | null;
  while ((m = anchor.exec(html)) && out.size < MAX_LINKS_PER_SOURCE) {
    const href = decode(m[3]).trim();
    const url = normalizeUrl(href, pageUrl);
    if (!url || !sameOfficialHost(url, sourceUrl)) continue;
    if (url === sourceUrl || new URL(url).pathname === "/") continue;
    const anchorTitle = cleanHtml(m[5]).replace(/\s+/g, " ").trim();
    const context = linkContext(html, m.index, anchor.lastIndex);
    const contextText = cleanHtml(context).split(/\n+/).map(s => s.trim()).filter(Boolean);
    const contextCandidates = contextText
      .filter(line => line.length >= 9 && line.length <= 240 && !JUNK.test(line))
      .filter(line => classify(line, url) !== null)
      .sort((a, b) => b.length - a.length);
    const title = validTitle(anchorTitle) ? anchorTitle : (contextCandidates[0] || "");
    if (!validTitle(title)) continue;
    const type = classify(`${title} ${contextText.join(" ").slice(0, 500)}`, url);
    if (!type) continue;
    const path = new URL(url).pathname.toLowerCase();
    if (/\.(pdf)$/i.test(path) || /\b(recruitment|vacancy|advertisement|notification|result|admit.?card|answer.?key|syllabus|exam|notice|corrigendum|scholarship|admission)\b/i.test(`${title} ${path}`)) {
      out.set(url, { title, url, type });
    }
  }
  return [...out.values()];
}

async function fetchText(url: string, maxBytes: number): Promise<{ body: string; bytes: Uint8Array; contentType: string; status: number; finalUrl: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const response = await fetch(url, { signal: controller.signal, redirect: "follow", headers: { "user-agent": "CareerPortalNoticeMonitor/2.0 (+https://careerportal.space/)", accept: "text/html,application/pdf,application/xhtml+xml;q=0.9,*/*;q=0.5" }, cache: "no-store" });
    const contentType = (response.headers.get("content-type") || "").toLowerCase();
    if (!response.ok) throw new Error(`HTTP ${response.status} ${response.statusText}`);
    const declared = Number(response.headers.get("content-length") || 0);
    if (declared > maxBytes) throw new Error("Source document exceeds the allowed size limit.");
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > maxBytes) throw new Error("Source document exceeds the allowed size limit.");
    return { body: new TextDecoder("utf-8", { fatal: false }).decode(bytes), bytes, contentType, status: response.status, finalUrl: response.url || url };
  } finally { clearTimeout(timer); }
}
async function readNotice(url: string): Promise<{ text: string; method: string; finalUrl: string }> {
  const fetched = await fetchText(url, MAX_NOTICE_BYTES);
  const looksPdf = fetched.contentType.includes("pdf") || url.toLowerCase().split(/[?#]/)[0].endsWith(".pdf") || fetched.body.slice(0, 5) === "%PDF-";
  if (looksPdf) {
    const pdfModule = await import("pdf-parse");
    const PDFParse = (pdfModule as unknown as { PDFParse?: new (args: { data: Uint8Array }) => { getText: () => Promise<{ text?: string; total?: number }>; destroy: () => Promise<void> } }).PDFParse;
    if (!PDFParse) throw new Error("Installed pdf-parse version does not expose PDFParse.");
    const parser = new PDFParse({ data: fetched.bytes });
    try {
      const parsed = await parser.getText();
      const text = String(parsed.text || "").trim();
      if (text.length < 40) throw new Error("PDF में readable text नहीं मिला; यह scanned PDF हो सकती है और OCR चाहिए।");
      return { text: text.slice(0, 180_000), method: "pdf-text", finalUrl: fetched.finalUrl };
    } finally { await parser.destroy(); }
  }
  const text = cleanHtml(fetched.body);
  if (text.length < 80) throw new Error("Notice page से पर्याप्त text नहीं मिला; source JavaScript/blocking use कर सकता है।");
  return { text: text.slice(0, 180_000), method: "html-text", finalUrl: fetched.finalUrl };
}
function first(text: string, labels: string[]): string {
  for (const label of labels) {
    const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const re = new RegExp(`(?:^|\\n|\\b)${escaped}\\s*(?:[:：–—-]|\\s{1,3})\\s*([^\\n]{2,240})`, "im");
    const value = text.match(re)?.[1]?.trim().replace(/[.;,\s]+$/, "");
    if (value && !/^(?:click here|read more|view details)$/i.test(value)) return value;
  }
  return "";
}
function extractFields(text: string, candidate: Candidate, source: Source, sourceHome: string, noticeUrl: string): Json {
  const lines = text.split(/\n+/).map(s => s.trim()).filter(Boolean);
  const fields: Json = {
    title: candidate.title,
    content_type: candidate.type,
    organization: source.name,
    official_website: sourceHome,
    notification_url: /\.pdf(?:$|[?#])/i.test(noticeUrl) ? noticeUrl : "",
    source_url: noticeUrl,
    source_homepage: sourceHome,
    source_code: source.code,
    extraction_method: "official-notice-text",
    description: text.slice(0, 12_000),
    raw_notice_text: text.slice(0, 30_000),
  };
  const mapping: Record<string, string[]> = {
    post_name: ["Name of Post", "Post Name", "Name of the Post", "Post(s)", "Designation"],
    total_vacancies: ["Total Vacancies", "Total Posts", "No. of Vacancies", "Number of Vacancies", "Vacancies"],
    qualification: ["Educational Qualification", "Essential Qualification", "Minimum Qualification", "Qualification", "Eligibility"],
    age_limit: ["Age Limit", "Age Criteria"], age_relaxation: ["Age Relaxation", "Relaxation in Age"],
    salary: ["Pay Scale", "Salary", "Pay Level", "Remuneration", "Pay"],
    application_fee: ["Application Fee", "Examination Fee", "Exam Fee", "Fee Details"],
    application_start: ["Application Start Date", "Online Application Start Date", "Registration Starts", "Start Date"],
    last_date: ["Last Date to Apply", "Last Date", "Closing Date", "Application Deadline", "Last date for submission"],
    exam_date: ["Exam Date", "Date of Examination", "Examination Date", "Exam Schedule"],
    result_date: ["Result Date", "Date of Result"], admit_card_date: ["Admit Card Date", "Hall Ticket Date"],
    selection_process: ["Selection Process", "Mode of Selection"], job_location: ["Job Location", "Place of Posting", "Location"],
    how_to_apply: ["How to Apply", "Application Process", "Apply Online"], required_documents: ["Documents Required", "Required Documents"],
    exam_name: ["Examination Name", "Exam Name", "Name of Examination"], course_duration: ["Course Duration", "Duration"],
    fees: ["Course Fee", "Course Fees", "Tuition Fee"], publication_date: ["Notification Date", "Date of Notification", "Published on", "Advertisement Date"],
    important_dates: ["Important Dates", "Schedule", "Event Dates"], application_number: ["Advertisement Number", "Advertisement No", "Notification Number", "Notice No"],
  };
  for (const [key, labels] of Object.entries(mapping)) { const value = first(text, labels); if (value) fields[key] = value; }
  // Retain tables/labelled content that doesn't fit known form fields instead of dropping it.
  fields.extracted_lines = lines.slice(0, 300);
  return fields;
}

async function getSources(db: SupabaseClient, sourceCode?: string): Promise<Source[]> {
  let query = db.from("content_sources").select("id,name,code,website_url,is_active").eq("is_active", true).order("name").limit(MAX_SOURCES_PER_RUN);
  if (sourceCode) query = query.ilike("code", sourceCode);
  const { data, error } = await query;
  if (error) throw new Error(`Configured sources read failed: ${error.message}`);
  return (data || []).map((r: any) => ({ id: String(r.id || ""), name: String(r.name || r.code || "Official source"), code: String(r.code || "").toUpperCase(), website_url: String(r.website_url || ""), is_active: r.is_active })).filter((s: Source) => s.id && s.code && /^https:\/\//i.test(s.website_url));
}

export async function runOfficialNoticeMonitor(db: SupabaseClient, sourceCode?: string) {
  const sources = await getSources(db, sourceCode);
  if (!sources.length) throw new Error(sourceCode ? `Active source '${sourceCode}' नहीं मिला या उसका HTTPS URL configured नहीं है।` : "content_sources में कोई active HTTPS source configured नहीं है।");
  const summary: Array<{ source: string; found: number; created: number; duplicates: number; errors: string[] }> = [];
  for (const source of sources) {
    const row = { source: source.code, found: 0, created: 0, duplicates: 0, errors: [] as string[] };
    summary.push(row);
    let homepage: string;
    try {
      const root = new URL(source.website_url);
      if (root.protocol !== "https:") throw new Error("HTTPS required");
      homepage = root.toString();
      const page = await fetchText(homepage, MAX_HTML_BYTES);
      if (!page.contentType.includes("html") && !page.body.includes("<a")) throw new Error(`Source returned non-HTML (${page.contentType || "unknown content type"}).`);
      const candidates = findCandidates(page.body, page.finalUrl, source.website_url);
      row.found = candidates.length;
      if (!candidates.length) continue;
      const { data: existing, error: existingError } = await db.from("content_import_queue").select("source_url").eq("source_code", source.code).limit(10000);
      if (existingError) throw new Error(`Queue duplicate check failed: ${existingError.message}`);
      const seen = new Set((existing || []).map((x: any) => String(x.source_url || "")).filter(Boolean));
      for (const candidate of candidates) {
        if (seen.has(candidate.url)) { row.duplicates++; continue; }
        seen.add(candidate.url);
        let noticeText = "";
        let extractionMethod = "link-metadata-only";
        let finalNoticeUrl = candidate.url;
        let details: Json = {};
        try {
          const notice = await readNotice(candidate.url);
          noticeText = notice.text;
          extractionMethod = notice.method;
          finalNoticeUrl = notice.finalUrl;
          details = extractFields(noticeText, candidate, source, source.website_url, finalNoticeUrl);
        } catch (e) {
          // Honest partial import: keep the verified notice URL and the extraction error; never invent missing fields.
          details = { title: candidate.title, content_type: candidate.type, official_website: source.website_url, source_homepage: source.website_url, source_code: source.code, source_url: candidate.url, extraction_error: e instanceof Error ? e.message : "Notice extraction failed", extraction_method: extractionMethod, review_required: true };
        }
        const contentData: Json = { ...details, title: candidate.title, content_type: candidate.type, official_website: source.website_url, source_url: finalNoticeUrl, source_homepage: source.website_url, source_code: source.code, discovered_at: new Date().toISOString(), review_required: true, auto_published: false };
        const queueRow = {
          source_id: source.id,
          source_code: source.code,
          source_name: source.name,
          source_url: finalNoticeUrl,
          source_title: candidate.title,
          title: candidate.title,
          content_type: candidate.type,
          item_type: candidate.type,
          status: "pending",
          content_data: contentData,
          normalized_content: contentData,
          raw_content: { title: candidate.title, url: finalNoticeUrl, text: noticeText.slice(0, 30_000), extraction_method: extractionMethod },
          payload: contentData,
          metadata: { source_code: source.code, source_name: source.name, source_homepage: source.website_url, notice_type: candidate.type, extraction_method: extractionMethod, review_required: true, auto_published: false },
        };
        const { error: insertError } = await db.from("content_import_queue").insert(queueRow);
        if (insertError) {
          // Unique constraints, if configured, are treated as duplicate rather than a source-wide failure.
          if (/duplicate|unique constraint/i.test(insertError.message)) { row.duplicates++; continue; }
          row.errors.push(`${candidate.title}: ${insertError.message}`);
          continue;
        }
        row.created++;
      }
    } catch (e) {
      row.errors.push(e instanceof Error ? e.message : "Source check failed.");
    }
  }
  return { success: summary.some(s => !s.errors.length), sourcesChecked: summary.length, found: summary.reduce((n, s) => n + s.found, 0), created: summary.reduce((n, s) => n + s.created, 0), duplicates: summary.reduce((n, s) => n + s.duplicates, 0), summary };
}
